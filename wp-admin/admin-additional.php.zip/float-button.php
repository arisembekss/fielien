  <div class="float-scroll">
  <div class="w3-tooltip">
  <span style="position:absolute;left:0;bottom:45px;color: #607d8b" class="w3-text"><b>back to top</b></span>

  <a href="#top" class="w3-btn-floating w3-ripple w3-teal" >^</a>
  </div>
  </div>