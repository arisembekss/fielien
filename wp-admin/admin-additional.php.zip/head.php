<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="../style/w3.css">

<script type="text/javascript" src="../js/index.js"></script>
<script type="text/javascript" src="admin.js"></script>

<link rel="stylesheet" href="../style/font-awesome-4.6.3/css/font-awesome.min.css">